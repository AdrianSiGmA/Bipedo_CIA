#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Vector3Stamped
from std_msgs.msg import Float32

RPY_real = [0.0,0.0,0.0,0.0]     # Arreglo donde se leen Roll, Pitch & Yaw (UM7) y Yaw (MPU6050)
Mag_ang = [0.0,0.0,0.0]

offset_mpu = 0.0
offset_um7 = 0.0
bandera_offset = 0

def CallBack_UM7_rpy(RPY_data):

    RPY_real[0] = RPY_data.vector.x*57.2958
    RPY_real[1] = RPY_data.vector.y*57.2958
    RPY_real[2] = RPY_data.vector.z*57.2958

def CallBack_UM7_mag(Mag_data):

    Mag_ang[0] = Mag_data.vector.x*70
    Mag_ang[1] = Mag_data.vector.y*70
    Mag_ang[2] = Mag_data.vector.z*70

def CallBack_MPU6050(Yaw_data):

    RPY_real[3] = Yaw_data.data

def RPY_listener_and_Real_RPY_publisher():
    # Nombre del nodo, false para que no despliegue numero aleatorio
    rospy.init_node('rpy_plot_node', anonymous=False)
    print("Inicializando rpy_plot_node...")

    # Definicion del publicador
    pub_real_rpy_plot = rospy.Publisher('/real_rpy_plot', Pose, queue_size=10)

    # Definicion del subscriptor
    rospy.Subscriber('/imu/rpy', Vector3Stamped, CallBack_UM7_rpy)
    rospy.Subscriber('/imu/mag', Vector3Stamped, CallBack_UM7_mag)
    rospy.Subscriber('/yaw', Float32, CallBack_MPU6050)

    # Velocidad del programa
    rate = rospy.Rate(500) # (10) = 10[Hz]

    real_rpy = Pose()

    # ============== WHILE LOOP ===========================
    while not rospy.is_shutdown():  # Confirma que todo esta bien
        global bandera_offset

        # Para obtener el offset del angulo despues de calibrarlo
        if bandera_offset == 0:
            # Filtro de datos
            for i in range(1,200):
                offset_mpu = RPY_real[3]
                offset_um7 = RPY_real[2]
                bandera_offset = 1
                # Publicacion del mensaje
                pub_real_rpy_plot.publish(real_rpy)
                # Delay del programa definido en el rate
                rate.sleep()
            print "Offset MPU-6050: ",offset_mpu

        # Datos del magnetometro UM7 transformados a tipo Pose
        real_rpy.position.x = Mag_ang[0]
        real_rpy.position.y = Mag_ang[1]
        real_rpy.position.z = Mag_ang[2]

        # Datos de RPY UM7 y Yaw MPU6050 transformados a tipo Pose
        real_rpy.orientation.x = RPY_real[0]                # Roll Real
        real_rpy.orientation.y = RPY_real[1]                # Pitch Real
        real_rpy.orientation.z = RPY_real[2]                # Yaw Falso
        real_rpy.orientation.w = RPY_real[3] - offset_mpu   # Yaw Real

        #print real_rpy.orientation.w
        # Publicacion del mensaje
        pub_real_rpy_plot.publish(real_rpy)

        # Delay del programa definido en el rate
        rate.sleep()

# ================= LOOP =====================
if __name__ == '__main__':
    try:
        RPY_listener_and_Real_RPY_publisher()
    except rospy.ROSInterruptException:
        pass
