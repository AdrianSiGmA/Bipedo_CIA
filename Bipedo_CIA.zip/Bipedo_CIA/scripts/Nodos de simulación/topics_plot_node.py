#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Vector3Stamped
from std_msgs.msg import Float32
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32MultiArray

RPY_real = [0.0,0.0,0.0,0.0]     # Arreglo donde se leen Roll, Pitch & Yaw (UM7) y Yaw (MPU6050)
Mag_ang = [0.0,0.0,0.0]
PWM = [0,0,0,0,0,0,0,0,0,0,0,0] # 12 Servomotores
flex = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]    # 14 flex graficados
pots = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]    # 14 pots graficados

offset_mpu = 0.0
offset_um7 = 0.0
bandera_offset = 0

def CallBack_UM7_rpy(RPY_data):
    RPY_real[0] = RPY_data.vector.x*57.2958
    RPY_real[1] = RPY_data.vector.y*57.2958
    RPY_real[2] = RPY_data.vector.z*57.2958

def CallBack_UM7_mag(Mag_data):
    Mag_ang[0] = Mag_data.vector.x*70
    Mag_ang[1] = Mag_data.vector.y*70
    Mag_ang[2] = Mag_data.vector.z*70

def CallBack_MPU6050_yaw(Yaw_data):
    RPY_real[3] = Yaw_data.data

def CallBack_Servos_compu(servos_data):
    PWM[0] = servos_data.data[0]
    PWM[1] = servos_data.data[1]
    PWM[2] = servos_data.data[2]
    PWM[3] = servos_data.data[3]
    PWM[4] = servos_data.data[4]
    PWM[5] = servos_data.data[5]
    PWM[6] = servos_data.data[6]
    PWM[7] = servos_data.data[7]
    PWM[8] = servos_data.data[8]
    PWM[9] = servos_data.data[9]
    PWM[10] = servos_data.data[10]
    PWM[11] = servos_data.data[11]

def CallBack_flex(flex_data):
    flex[0] = flex_data.data[0]
    flex[1] = flex_data.data[1]
    flex[2] = flex_data.data[2]
    flex[3] = flex_data.data[3]
    flex[4] = flex_data.data[4]
    flex[5] = flex_data.data[5]
    flex[6] = flex_data.data[6]
    flex[7] = flex_data.data[7]
    flex[8] = flex_data.data[8]
    flex[9] = flex_data.data[9]
    flex[10] = flex_data.data[10]
    flex[11] = flex_data.data[11]
    flex[12] = flex_data.data[12]
    flex[13] = flex_data.data[13]

def CallBack_pots(pots_data):
    pots[0] = pots_data.data[0]
    pots[1] = pots_data.data[1]
    pots[2] = pots_data.data[2]
    pots[3] = pots_data.data[3]
    pots[4] = pots_data.data[4]
    pots[5] = pots_data.data[5]
    pots[6] = pots_data.data[6]
    pots[7] = pots_data.data[7]
    pots[8] = pots_data.data[8]
    pots[9] = pots_data.data[9]
    pots[10] = pots_data.data[10]
    pots[11] = pots_data.data[11]
    pots[12] = pots_data.data[12]
    pots[13] = pots_data.data[13]

def RPY_listener_and_Real_RPY_publisher():
    # Nombre del nodo, false para que no despliegue numero aleatorio
    rospy.init_node('topics_plot_node', anonymous=False)
    print("Inicializando topics_plot_node...")

    # Definicion del publicador
    pub_real_rpy_plot = rospy.Publisher('/real_rpy_plot', Pose, queue_size=10)
    pub_servos_izq_compu_plot = rospy.Publisher('/servos_izq_compu_plot', Pose, queue_size=10)
    pub_servos_der_compu_plot = rospy.Publisher('/servos_der_compu_plot', Pose, queue_size=10)
    pub_flex1_plot = rospy.Publisher('/flex1_plot', Pose, queue_size=10)
    pub_flex2_plot = rospy.Publisher('/flex2_plot', Pose, queue_size=10)
    pub_pots1_plot = rospy.Publisher('/pots1_plot', Pose, queue_size=10)
    pub_pots2_plot = rospy.Publisher('/pots2_plot', Pose, queue_size=10)

    # Suscriptores para la comparacion de graficas y creacion del RPY real
    rospy.Subscriber('/imu/rpy', Vector3Stamped, CallBack_UM7_rpy)
    rospy.Subscriber('/imu/mag', Vector3Stamped, CallBack_UM7_mag)
    rospy.Subscriber('/yaw', Float32, CallBack_MPU6050_yaw)

    # Suscriptor para la graficacion de los servos de la compu
    rospy.Subscriber('/servos_topic', Int32MultiArray, CallBack_Servos_compu)

    # Suscriptor para la graficacion de los sensores flex y pots
    rospy.Subscriber('/flex', Float32MultiArray, CallBack_flex)
    rospy.Subscriber('/pots', Float32MultiArray, CallBack_pots)

    # Velocidad del programa
    rate = rospy.Rate(500) # (10) = 10[Hz]

    real_rpy = Pose()
    servos_izq_compu = Pose()
    servos_der_compu = Pose()
    flex1 = Pose()
    flex2 = Pose()
    pots1 = Pose()
    pots2 = Pose()

    # ============== WHILE LOOP ===========================
    while not rospy.is_shutdown():  # Confirma que todo esta bien
        global bandera_offset

        # Para obtener el offset del angulo despues de calibrarlo
        if bandera_offset == 0:
            # Filtro de datos
            for i in range(1,200):
                offset_mpu = RPY_real[3]
                offset_um7 = RPY_real[2]
                bandera_offset = 1
                # Publicacion del mensaje
                pub_real_rpy_plot.publish(real_rpy)
                # Delay del programa definido en el rate
                rate.sleep()

            print "offset de la MPU-6050: ",offset_mpu

        # Datos del magnetometro UM7 transformados a tipo Pose
        real_rpy.position.x = Mag_ang[0]
        real_rpy.position.y = Mag_ang[1]
        real_rpy.position.z = Mag_ang[2]

        # Datos de RPY REAL formado por: UM7 y Yaw MPU6050 transformados a tipo Pose
        real_rpy.orientation.x = RPY_real[0]
        real_rpy.orientation.y = RPY_real[1]
        real_rpy.orientation.z = RPY_real[2]
        real_rpy.orientation.w = RPY_real[3] - offset_mpu

        # Datos de los servos mandados desde la computadora
        servos_izq_compu.position.x = PWM[0]
        servos_izq_compu.position.y = PWM[1]
        servos_izq_compu.position.z = PWM[2]
        servos_izq_compu.orientation.x = PWM[3]
        servos_izq_compu.orientation.y = PWM[4]
        servos_izq_compu.orientation.z = PWM[5]
        servos_der_compu.position.x = PWM[6]
        servos_der_compu.position.y = PWM[7]
        servos_der_compu.position.z = PWM[8]
        servos_der_compu.orientation.x = PWM[9]
        servos_der_compu.orientation.y = PWM[10]
        servos_der_compu.orientation.z = PWM[11]

        flex1.position.x = flex[0]
        flex1.position.y = flex[1]
        flex1.position.z = flex[2]
        flex1.orientation.x = flex[3]
        flex1.orientation.y = flex[4]
        flex1.orientation.z = flex[5]
        flex1.orientation.w = flex[6]
        flex2.position.x = flex[7]
        flex2.position.y = flex[8]
        flex2.position.z = flex[9]
        flex2.orientation.x = flex[10]
        flex2.orientation.y = flex[11]
        flex2.orientation.z = flex[12]
        flex2.orientation.w = flex[13]

        pots1.position.x = pots[0]
        pots1.position.y = pots[1]
        pots1.position.z = pots[2]
        pots1.orientation.x = pots[3]
        pots1.orientation.y = pots[4]
        pots1.orientation.z = pots[5]
        pots1.orientation.w = pots[6]
        pots2.position.x = pots[7]
        pots2.position.y = pots[8]
        pots2.position.z = pots[9]
        pots2.orientation.x = pots[10]
        pots2.orientation.y = pots[11]
        pots2.orientation.z = pots[12]
        pots2.orientation.w = pots[13]

        # Publicacion del mensaje
        pub_real_rpy_plot.publish(real_rpy)
        pub_servos_izq_compu_plot.publish(servos_izq_compu)
        pub_servos_der_compu_plot.publish(servos_der_compu)
        pub_flex1_plot.publish(flex1)
        pub_flex2_plot.publish(flex2)
        pub_pots1_plot.publish(pots1)
        pub_pots2_plot.publish(pots2)

        # Delay del programa definido en el rate
        rate.sleep()

# ================= LOOP =====================
if __name__ == '__main__':
    try:
        RPY_listener_and_Real_RPY_publisher()
    except rospy.ROSInterruptException:
        pass
