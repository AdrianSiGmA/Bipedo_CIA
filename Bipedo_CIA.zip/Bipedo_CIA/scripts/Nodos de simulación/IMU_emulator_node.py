#!/usr/bin/env python

# ------------- DEPENDENCIAS Y BIBLIOTECAS  ------------------
import rospy
import random
from geometry_msgs.msg import Pose
from geometry_msgs.msg import Vector3Stamped
from std_msgs.msg import Float32

# ====================== Publicador =======================
def RPY_talker():
    # Definicion del publicador
    pub = rospy.Publisher('/imu/rpy', Vector3Stamped, queue_size=10)
    pub_plot = rospy.Publisher('/imu_rpy_plot', Pose, queue_size=10)
    pub_yaw = rospy.Publisher('/yaw', Float32, queue_size=10)

    # Nombre del nodo, false para que no despliegue numero aleatorio
    rospy.init_node('IMU_emulator_node', anonymous=False)
    print("Inicializando IMU_emulator_node...")

    # Velocidad del programa
    rate = rospy.Rate(100) # (10) = 10[Hz]

    # Servos es el arreglo donde se guardaran los datos a escribir a los motores
    rpy = Vector3Stamped()
    rpy_plot = Pose()
    yaw = Float32()

    rpy.vector.x = 0.0
    rpy.vector.y = 0.0
    rpy.vector.z = 0.0

    yaw.data = 300.0    # Simulando que es la MPU-6050

    # Para graficar 
    rpy_plot.position.x = 0
    rpy_plot.position.y = 0
    rpy_plot.position.z = 0

    bandera_calibracion = False

    # ============== WHILE LOOP ===========================
    while not rospy.is_shutdown():  # Confirma que todo esta bien
        if bandera_calibracion == False:
            for i in range(0,1790):
                yaw.data = yaw.data - 0.045
                rpy.vector.x = 0.0 + random.randint(-1,1)*0.001
                rpy.vector.y = 0.0 + random.randint(-1,1)*0.001

                pub.publish(rpy)
                pub_yaw.publish(yaw)
                rate.sleep()

            yaw_calibrado = yaw.data
            bandera_calibracion = True

        # Almacenamiento en arreglo del publicador
        rpy.vector.x = 0.0 + random.randint(-1,1)*0.001
        rpy.vector.y = 0.0 + random.randint(-1,1)*0.001
        yaw.data = yaw_calibrado + random.randint(-1,1)*0.02
        #rpy_plot.position.x = i*0.01
        #rpy_plot.position.y = -i*0.01

        # Publicacion del mensaje
        pub.publish(rpy)
        #pub_plot.publish(rpy_plot)
        pub_yaw.publish(yaw)

        # Delay del programa definido en el rate
        rate.sleep()

# ================= LOOP =====================
if __name__ == '__main__':
    try:
        RPY_talker()
    except rospy.ROSInterruptException:
        pass