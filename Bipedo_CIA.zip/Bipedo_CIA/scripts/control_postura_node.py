#!/usr/bin/env python

# ------------- DEPENDENCIAS Y BIBLIOTECAS  ------------------
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import time
from time import time as Time_c
import random
import math

import rospy
from std_msgs.msg import Int32MultiArray
from geometry_msgs.msg import Vector3Stamped
from geometry_msgs.msg import Pose

dim_captura = 820
datos_recabados = np.zeros((dim_captura,33))

eP_pitch = np.arange(-90, 90,0.1)

eP_pitch_ENG = fuzz.trimf(eP_pitch, [-90,-90,-15])#error negativo grande
eP_pitch_ENP = fuzz.trimf(eP_pitch,[-60,-15,0])#error negativo pequeno
eP_pitch_ECC = fuzz.trapmf(eP_pitch,[-15,-5,5,15])#error cercano cero
eP_pitch_EPP = fuzz.trimf(eP_pitch,[0,15,60])#error positivo pequeno
eP_pitch_EPG = fuzz.trimf(eP_pitch, [15,90,90])#error positivo grande

eI_pitch = np.arange(-200, 200,0.1)

eI_pitch_ENG = fuzz.trimf(eI_pitch, [-200,-200,-50])#error negativo grande
eI_pitch_ENP = fuzz.trimf(eI_pitch,[-100,-50,0])#error negativo pequeno
eI_pitch_ECC = fuzz.trimf(eI_pitch,[-50,0,50])#error cercano cero
eI_pitch_EPP = fuzz.trimf(eI_pitch,[0,50,100])#error positivo pequeno
eI_pitch_EPG = fuzz.trimf(eI_pitch, [50,200,200])#error positivo grande

eD_pitch = np.arange(-300, 300,0.1)

eD_pitch_ENG = fuzz.trimf(eD_pitch, [-300,-300,-50])#error negativo grande
eD_pitch_ENP = fuzz.trimf(eD_pitch,[-100,-50,0])#error negativo pequeno
eD_pitch_ECC = fuzz.trapmf(eD_pitch,[-50,-5,5,50])#error cercano cero
eD_pitch_EPP = fuzz.trimf(eD_pitch,[0,50,100])#error positivo pequeno
eD_pitch_EPG = fuzz.trimf(eD_pitch, [50,300,300])#error positivo grande

eP_roll = np.arange(-90, 90,0.1)

eP_roll_ENG = fuzz.trimf(eP_roll, [-90,-90,-15])#error negativo grande
eP_roll_ENP = fuzz.trimf(eP_roll,[-60,-25,0])#error negativo pequeno
eP_roll_ECC = fuzz.trapmf(eP_roll,[-25,-5,5,25])#error cercano cero
eP_roll_EPP = fuzz.trimf(eP_roll,[0,25,60])#error positivo pequeno
eP_roll_EPG = fuzz.trimf(eP_roll, [15,90,90])#error positivo grande

KP = np.arange(0,1.5,0.1)#angulo inicial robot: 115

KP_mf1 = fuzz.trapmf(KP, [0, 0,0.2,0.4])#angulo cercano cero
KP_mf2 = fuzz.trimf(KP, [0.2, 0.4, 0.6])#angulo pequeno cero
KP_mf3 = fuzz.trimf(KP,[0.4,0.6,0.8])#angulo mitad
KP_mf4 = fuzz.trimf(KP, [0.6, 0.9, 1.1])#angulo pequeno mitad
KP_mf5 = fuzz.trapmf(KP, [0.9, 1.1, 1.5,1.5])#angulo casi final


KI = np.arange(0,1.5,0.1)#angulo inicial robot: 65

KI_mf1 = fuzz.trapmf(KI, [0, 0,0.2,0.4])#angulo cercano cero
KI_mf2 = fuzz.trimf(KI, [0.2, 0.4, 0.6])#angulo pequeno cero
KI_mf3 = fuzz.trimf(KI,[0.4,0.6,0.8])#angulo mitad
KI_mf4 = fuzz.trimf(KI, [0.6, 0.9, 1.1])#angulo pequeno mitad
KI_mf5 = fuzz.trapmf(KI, [0.9, 1.1, 1.5,1.5])#angulo casi final

KD = np.arange(0,0.5,0.1)#angulo inicial robot: 140

KD_mf1 = fuzz.trimf(KD,[ 0,0,0.1])#angulo cercano cero
KD_mf2 = fuzz.trimf(KD, [0, 0.1, 0.2])#angulo pequeno cero
KD_mf3 = fuzz.trimf(KD,[0.1,0.2,0.3])#angulo mitad
KD_mf4 = fuzz.trimf(KD, [0.2, 0.3, 0.4])#angulo pequeno mitad
KD_mf5 = fuzz.trapmf(KD, [0.3, 0.4, 0.5,0.5])#angulo casi final

KP_roll = np.arange(0,1.5,0.1)#angulo inicial robot: 115

KP_roll_mf1 = fuzz.trapmf(KP_roll, [0, 0,0.1,0.2])#angulo cercano cero
KP_roll_mf2 = fuzz.trimf(KP_roll, [0.1, 0.2, 0.4])#angulo pequeno cero
KP_roll_mf3 = fuzz.trimf(KP_roll,[0.2,0.4,0.8])#angulo mitad
KP_roll_mf4 = fuzz.trimf(KP_roll, [0.6, 0.8, 1.1])#angulo pequeno mitad
KP_roll_mf5 = fuzz.trapmf(KP_roll, [0.8, 1.1, 1.5,1.5])#angulo casi final

KP_roll_c = np.arange(0,2.5,0.1)#angulo inicial robot: 115

KP_roll_c_mf1 = fuzz.trapmf(KP_roll_c, [0, 0,0.4,0.8])#angulo cercano cero
KP_roll_c_mf2 = fuzz.trimf(KP_roll_c, [0.4, 0.8, 1.2])#angulo pequeno cero
KP_roll_c_mf3 = fuzz.trimf(KP_roll_c,[0.8,1.2,1.6])#angulo mitad
KP_roll_c_mf4 = fuzz.trimf(KP_roll_c, [1.2, 1.6, 2.0])#angulo pequeno mitad
KP_roll_c_mf5 = fuzz.trapmf(KP_roll_c, [1.6, 2.0, 2.5,2.5])#angulo casi final

Ang_RodillaD = np.arange(0,35,1)#angulo inicial robot: 140

Ang_RodillaD_mf1 = fuzz.trapmf(Ang_RodillaD,[0,0,10,15])#angulo cercano cero
Ang_RodillaD_mf2 = fuzz.trimf(Ang_RodillaD,[10, 15,20])#angulo pequeno cero
Ang_RodillaD_mf3 = fuzz.trimf(Ang_RodillaD,[15,20,25])#angulo mitad
Ang_RodillaD_mf4 = fuzz.trimf(Ang_RodillaD,[20,25,30])#angulo pequeno mitad
Ang_RodillaD_mf5 = fuzz.trapmf(Ang_RodillaD,[25,30,35, 35])#angulo casi final

Ang_RodillaI = np.arange(0,35,1)#angulo inicial robot: 140

Ang_RodillaI_mf1 = fuzz.trapmf(Ang_RodillaI,[0,0,10,15])#angulo cercano cero
Ang_RodillaI_mf2 = fuzz.trimf(Ang_RodillaI,[10, 15,20])#angulo pequeno cero
Ang_RodillaI_mf3 = fuzz.trimf(Ang_RodillaI,[15,20,25])#angulo mitad
Ang_RodillaI_mf4 = fuzz.trimf(Ang_RodillaI,[20,25,30])#angulo pequeno mitad
Ang_RodillaI_mf5 = fuzz.trapmf(Ang_RodillaI,[25,30,35,35])#angulo casi final


def ErrorP_category(error_in):
    eP_pitch_ENG_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ENG,error_in)
    eP_pitch_ENP_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ENP,error_in)
    eP_pitch_ECC_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ECC,error_in)
    eP_pitch_EPP_cat = fuzz.interp_membership(eP_pitch,eP_pitch_EPP,error_in)
    eP_pitch_EPG_cat = fuzz.interp_membership(eP_pitch,eP_pitch_EPG,error_in)
    return dict(NG = eP_pitch_ENG_cat, NP = eP_pitch_ENP_cat, CE = eP_pitch_ECC_cat, PP = eP_pitch_EPP_cat, PG = eP_pitch_EPG_cat)
    
def ErrorI_category(error_in):
    eI_pitch_ENG_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ENG,error_in)
    eI_pitch_ENP_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ENP,error_in)
    eI_pitch_ECC_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ECC,error_in)
    eI_pitch_EPP_cat = fuzz.interp_membership(eI_pitch,eI_pitch_EPP,error_in)
    eI_pitch_EPG_cat = fuzz.interp_membership(eI_pitch,eI_pitch_EPG,error_in)
    return dict(NG = eI_pitch_ENG_cat, NP = eI_pitch_ENP_cat, CE = eI_pitch_ECC_cat, PP = eI_pitch_EPP_cat, PG = eI_pitch_EPG_cat)
    
def ErrorD_category(error_in):
    eD_pitch_ENG_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ENG,error_in)
    eD_pitch_ENP_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ENP,error_in)
    eD_pitch_ECC_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ECC,error_in)
    eD_pitch_EPP_cat = fuzz.interp_membership(eD_pitch,eD_pitch_EPP,error_in)
    eD_pitch_EPG_cat = fuzz.interp_membership(eD_pitch,eD_pitch_EPG,error_in)
    return dict(NG = eD_pitch_ENG_cat, NP = eD_pitch_ENP_cat, CE = eD_pitch_ECC_cat, PP = eD_pitch_EPP_cat, PG = eD_pitch_EPG_cat)
    
def ErrorP_roll_category(error_in):
    eP_roll_ENG_cat = fuzz.interp_membership(eP_roll,eP_roll_ENG,error_in)
    eP_roll_ENP_cat = fuzz.interp_membership(eP_roll,eP_roll_ENP,error_in)
    eP_roll_ECC_cat = fuzz.interp_membership(eP_roll,eP_roll_ECC,error_in)
    eP_roll_EPP_cat = fuzz.interp_membership(eP_roll,eP_roll_EPP,error_in)
    eP_roll_EPG_cat = fuzz.interp_membership(eP_roll,eP_roll_EPG,error_in)
    return dict(NG = eP_roll_ENG_cat, NP = eP_roll_ENP_cat, CE = eP_roll_ECC_cat, PP = eP_roll_EPP_cat, PG = eP_roll_EPG_cat)
    

def Limites(angulo):
    if angulo > 180:
        angulo = 180
    if angulo < 0:
        angulo = 0
    return angulo

# ------------------------ VARIABLES GLOBALES ------------------------
PWM = [0,0,0,0,0,0,0,0,0,0,0,0] # 12 Servomotores
RPY = [0.0,0.0,0.0]     # Arreglo donde se leen Roll, Pitch & Yaw

ahora_t = 0
ultimo_t = 0
dt = 0
error_sum = 0
contador = 0
tiempo = 0
suma_tiempo = 0
filter_rate = 0
error_roll = 0
error_pitch = 0
Kp = 0
Ki = 0
i = 0
U_21 = 0
U_22 = 0
U_31 = 0
U_32 = 0
U_41 = 0
U_42 = 0
U_51 = 0
U_52 = 0
U_61 = 0
U_62 = 0

# =================== CALLBACK de ROS ==============================
def CallBack(RPY_data):
    # Uso de variables globales
    global ahora_t, ultimo_t, error_roll, error_pitch, filter_rate
    global dt, error_sum, contador, tiempo, suma_tiempo, i
    global U_21, U_22, U_31, U_32, U_41, U_42, U_51, U_52, U_61, U_62

    ahora_t = Time_c() # Para comenzar a medir tiempo
    # Almacenamiento de datos de la IMU
    RPY[0] = RPY_data.vector.x*57.2958
    RPY[1] = RPY_data.vector.y*57.2958
    RPY[2] = RPY_data.vector.z*57.2958

    # Calculo de los errores
    error_roll = 0 - RPY[0]
    error_pitch = 0 - RPY[1]
    error_rate = 0
    filter_rate = filter_rate + 0.1*(error_rate - filter_rate)
    ultimo_t = Time_c() # Para terminar de medir tiempo
    dt = ultimo_t - ahora_t # Diferencial de tiempo
    suma_tiempo  += dt      
    error_sum += (error_pitch*dt)

    #categorias errores pitch
    eP_rule = ErrorP_category(error_pitch) 
    eI_rule = ErrorI_category(error_sum)
    eD_rule = ErrorD_category(filter_rate)

    #categorias error roll
    eP_roll_rule = ErrorP_roll_category(error_roll) 
    
    #ERROR PITCH
    regla1_KP = np.fmax(eP_rule['NG'],eD_rule['NG'])
    regla2_KP = np.fmax(eP_rule['NP'],eD_rule['NP'])
    regla3_KP = np.fmax(eP_rule['CE'],eD_rule['CE'])
    regla4_KP = np.fmax(eP_rule['PP'],eD_rule['PP'])
    regla5_KP = np.fmax(eP_rule['PG'],eD_rule['PG'])
    
    #ERROR SUMA PITCH
    regla1_KI = np.fmax(eP_rule['NG'],eI_rule['NG'])
    regla2_KI = np.fmax(eP_rule['NP'],eI_rule['NP'])
    regla3_KI = np.fmax(eP_rule['CE'],eI_rule['CE'])
    regla4_KI = np.fmax(eP_rule['PP'],eI_rule['PP'])
    regla5_KI = np.fmax(eP_rule['PG'],eI_rule['PG'])
    
    #CAMBIO ERROR  PITCH
    regla1_KD = np.fmax(eP_rule['NG'],eD_rule['NG'])
    regla2_KD = eP_rule['NP']
    regla3_KD = eP_rule['CE']
    regla4_KD = eP_rule['PP']
    regla5_KD = np.fmax(eP_rule['PG'],eD_rule['PG'])
    
    #ERROR ROLL
    regla1_KP_roll = eP_roll_rule['NG']
    regla2_KP_roll = eP_roll_rule['NP']
    regla3_KP_roll = eP_roll_rule['CE']
    regla4_KP_roll = eP_roll_rule['PP']
    regla5_KP_roll = eP_roll_rule['PG']
    
    #ERROR ROLL cadera
    regla1_KP_roll_c = eP_roll_rule['NG']
    regla2_KP_roll_c = eP_roll_rule['NP']
    regla3_KP_roll_c = eP_roll_rule['CE']
    regla4_KP_roll_c = eP_roll_rule['PP']
    regla5_KP_roll_c = eP_roll_rule['PG']
    
    #ANGULO RODILLA 
    regla1_ang_rodillaD = eP_roll_rule['NG']
    regla2_ang_rodillaD = eP_roll_rule['NP']
    regla3_ang_rodillaD = eP_roll_rule['CE']
    regla4_ang_rodillaD = eP_roll_rule['PP']
    regla5_ang_rodillaD = eP_roll_rule['PG']
    
    #ANGULO RODILLA 
    regla1_ang_rodillaI = eP_roll_rule['NG']
    regla2_ang_rodillaI = eP_roll_rule['NP']
    regla3_ang_rodillaI = eP_roll_rule['CE']
    regla4_ang_rodillaI = eP_roll_rule['PP']
    regla5_ang_rodillaI = eP_roll_rule['PG']
    
    #Implementacion de reglas KP,KI,KD
    regla1_KP_act = np.fmin(regla1_KP,KP_mf5)#si ENG y  entonces KP mf5 nivel alto
    regla2_KP_act = np.fmin(regla2_KP,KP_mf3)#si ENP y entonces KP mf2, nivel bajo
    regla3_KP_act = np.fmin(regla3_KP,KP_mf1)#si ECC y entonces KP mf3
    regla4_KP_act = np.fmin(regla4_KP,KP_mf3)#si EPP y entonces KP mf4
    regla5_KP_act = np.fmin(regla5_KP,KP_mf5)#si EPG y entonces KP mf5
    
    regla1_KI_act = np.fmin(regla1_KI,KI_mf1)#si ENG y ENG entonces KI mf1
    regla2_KI_act = np.fmin(regla2_KI,KI_mf2)#si ENP y entonces KI mf2
    regla3_KI_act = np.fmin(regla3_KI,KI_mf4)#si ECC y entonces KI mf3
    regla4_KI_act = np.fmin(regla4_KI,KI_mf2)#si EPP y entonces KI mf4
    regla5_KI_act = np.fmin(regla5_KI,KI_mf1)#si EPG y entonces KI mf5

    regla1_KD_act = np.fmin(regla1_KD,KD_mf5)#si ENG y ENG entonces KD mf1
    regla2_KD_act = np.fmin(regla2_KD,KD_mf2)#si ENP y entonces KD mf2
    regla3_KD_act = np.fmin(regla3_KD,KD_mf1)#si ECC y entonces KD mf3
    regla4_KD_act = np.fmin(regla4_KD,KD_mf2)#si EPP y entonces KD mf4
    regla5_KD_act = np.fmin(regla5_KD,KD_mf5)#si EPG y entonces KD mf5
    
    regla1_KP_roll_act = np.fmin(regla1_KP_roll,KP_roll_mf5)#si ENG y  entonces KP mf5 nivel alto
    regla2_KP_roll_act = np.fmin(regla2_KP_roll,KP_roll_mf3)#si ENP y entonces KP mf2, nivel bajo
    regla3_KP_roll_act = np.fmin(regla3_KP_roll,KP_roll_mf1)#si ECC y entonces KP mf3
    regla4_KP_roll_act = np.fmin(regla4_KP_roll,KP_roll_mf3)#si EPP y entonces KP mf4
    regla5_KP_roll_act = np.fmin(regla5_KP_roll,KP_roll_mf5)#si EPG y entonces KP mf5
    
    regla1_KP_roll_c_act = np.fmin(regla1_KP_roll_c,KP_roll_c_mf5)#si ENG y  entonces KP mf5 nivel alto
    regla2_KP_roll_c_act = np.fmin(regla2_KP_roll_c,KP_roll_c_mf2)#si ENP y entonces KP mf2, nivel bajo
    regla3_KP_roll_c_act = np.fmin(regla3_KP_roll_c,KP_roll_c_mf1)#si ECC y entonces KP mf3
    regla4_KP_roll_c_act = np.fmin(regla4_KP_roll_c,KP_roll_c_mf2)#si EPP y entonces KP mf4
    regla5_KP_roll_c_act = np.fmin(regla5_KP_roll_c,KP_roll_c_mf5)#si EPG y entonces KP mf5
    
    regla1_ang_rodillaD_act = np.fmin(regla1_ang_rodillaD,Ang_RodillaD_mf5)#si ENG y ENG entonces KD mf1
    regla2_ang_rodillaD_act = np.fmin(regla2_ang_rodillaD,Ang_RodillaD_mf4)#si ENP y entonces KD mf2
    regla3_ang_rodillaD_act = np.fmin(regla3_ang_rodillaD,Ang_RodillaD_mf2)#si ECC y entonces KD mf3
    regla4_ang_rodillaD_act = np.fmin(regla4_ang_rodillaD,Ang_RodillaD_mf4)#si EPP y entonces KD mf4
    regla5_ang_rodillaD_act = np.fmin(regla5_ang_rodillaD,Ang_RodillaD_mf5)#si EPG y entonces KD mf5
    
    regla1_ang_rodillaI_act = np.fmin(regla1_ang_rodillaI,Ang_RodillaI_mf5)#si ENG y ENG entonces KD mf1
    regla2_ang_rodillaI_act = np.fmin(regla2_ang_rodillaI,Ang_RodillaI_mf4)#si ENP y entonces KD mf2
    regla3_ang_rodillaI_act = np.fmin(regla3_ang_rodillaI,Ang_RodillaI_mf2)#si ECC y entonces KD mf3
    regla4_ang_rodillaI_act = np.fmin(regla4_ang_rodillaI,Ang_RodillaI_mf4)#si EPP y entonces KD mf4
    regla5_ang_rodillaI_act = np.fmin(regla5_ang_rodillaI,Ang_RodillaI_mf5)#si EPG y entonces KD mf5
    
    SumaMembresiasKP = np.fmax(regla1_KP_act,np.fmax(regla2_KP_act,np.fmax(regla3_KP_act,np.fmax(regla4_KP_act,regla5_KP_act))))
    SumaMembresiasKI =  np.fmax(regla1_KI_act,np.fmax(regla2_KI_act,np.fmax(regla3_KI_act,np.fmax(regla4_KI_act,regla5_KI_act))))
    SumaMembresiasKD = np.fmax(regla1_KD_act,np.fmax(regla2_KD_act,np.fmax(regla3_KD_act,np.fmax(regla4_KD_act,regla5_KD_act))))
    
    SumaMembresiasKP_roll = np.fmax(regla1_KP_roll_act,np.fmax(regla2_KP_roll_act,np.fmax(regla3_KP_roll_act,np.fmax(regla4_KP_roll_act,regla5_KP_roll_act))))
    SumaMembresiasKP_roll_c = np.fmax(regla1_KP_roll_c_act,np.fmax(regla2_KP_roll_c_act,np.fmax(regla3_KP_roll_c_act,np.fmax(regla4_KP_roll_c_act,regla5_KP_roll_c_act))))
    
    SumaMembresias_a_D = np.fmax(regla1_ang_rodillaD_act,np.fmax(regla2_ang_rodillaD_act,np.fmax(regla3_ang_rodillaD_act,np.fmax(regla4_ang_rodillaD_act,regla5_ang_rodillaD_act))))
    SumaMembresias_a_I = np.fmax(regla1_ang_rodillaI_act,np.fmax(regla2_ang_rodillaI_act,np.fmax(regla3_ang_rodillaI_act,np.fmax(regla4_ang_rodillaI_act,regla5_ang_rodillaI_act))))
    
    #defuzzification, resultado:
    Kp = fuzz.centroid(KP, SumaMembresiasKP)
    Ki = fuzz.centroid(KI, SumaMembresiasKI)
    Kd = fuzz.centroid(KD, SumaMembresiasKD) 
    
    Kp_roll = fuzz.centroid(KP_roll, SumaMembresiasKP_roll) 
    Kp_roll_c = fuzz.centroid(KP_roll_c, SumaMembresiasKP_roll_c) 
    
    a_D = fuzz.centroid(Ang_RodillaD, SumaMembresias_a_D) 
    a_I = fuzz.centroid(Ang_RodillaI, SumaMembresias_a_I) 

    U_21 = 90 + Kp_roll_c*error_roll
    U_22 = 90 + Kp_roll_c*error_roll
    #Originales Allen:
    '''U_31 = 160 - 0.2479*error_pitch - 0.804*error_sum - 0.056*error_rate - a_D
    U_32 = 35 + 0.2479*error_pitch + 0.804*error_sum + 0.056*error_rate +  a_I
    U_41 = 65 - 0.2479*error_pitch - 0.804*error_sum - 0.056*error_rate - a_D
    U_42 = 120 + 0.2479*error_pitch + 0.804*error_sum + 0.056*error_rate + a_I
    U_51 = 120 - 0.2479*error_pitch - 0.804*error_sum - 0.056*error_rate - a_D
    U_52 = 65 + 0.2479*error_pitch + 0.804*error_sum + 0.056*error_rate + a_I'''
    U_31 = 160 - 0.8479*error_pitch - 1.004*error_sum - 0.756*error_rate - a_D
    U_32 = 35 + 0.8479*error_pitch + 1.004*error_sum + 0.756*error_rate +  a_I
    U_41 = 65 - 0.8479*error_pitch - 1.004*error_sum - 0.756*error_rate - a_D
    U_42 = 120 + 0.8479*error_pitch + 1.004*error_sum + 0.756*error_rate + a_I
    U_51 = 120 - 0.8479*error_pitch - 1.004*error_sum - 0.756*error_rate - a_D
    U_52 = 65 + 0.8479*error_pitch + 1.004*error_sum + 0.756*error_rate + a_I
    U_61 = 90 + Kp_roll*error_roll
    U_62 = 90 + Kp_roll*error_roll

    servo11 = 90
    servo12 = 90
    servo21 = Limites(int(U_21))
    servo22 = Limites(int(U_22))
    servo31 = Limites(int(U_31))#cadera PID
    servo32 = Limites(int(U_32))#cadera PID
    servo41 = Limites(int(U_41))#Rodilla
    servo42 = Limites(int(U_42))#Rodilla
    servo51 = Limites(int(U_51))#Tobillo PID
    servo52 = Limites(int(U_52))#Tobillo PID
    servo61 = Limites(int(U_61))
    servo62 = Limites(int(U_62))

    PWM[0] = servo11             # servo11
    PWM[1] = servo12             # servo12
    PWM[2] = servo21             # servo21
    PWM[3] = servo22             # servo22
    PWM[4] = servo31#cadera PID  # servo31
    PWM[5] = servo32#cadera PID  # servo32
    PWM[6] = servo41#Rodilla     # servo41
    PWM[7] = servo42#Rodilla     # servo42
    PWM[8] = servo51#Tobillo PID # servo51
    PWM[9] = servo52#Tobillo PID # servo52
    PWM[10] = servo61            # servo61
    PWM[11] = servo62            # servo62

# ====================== Publicador y Subscriptor =======================
def RPY_listener_and_PWM_talker():

    # Nombre del nodo, false para que no despliegue numero aleatorio
    rospy.init_node('control_postura_node', anonymous=False)
    print("Inicializando control_postura_node...")

    # Definicion del publicador
    pub = rospy.Publisher('/servos_topic', Int32MultiArray, queue_size=10)
    pub_plot = rospy.Publisher('/servo_plot_compu', Pose, queue_size=10)

    # Definicion del subscriptor
    rospy.Subscriber('/imu/rpy', Vector3Stamped, CallBack)
    #rospy.spin() <-------- este es remplazado por while not rospy.is_shutdown()    

    # Velocidad del programa
    rate = rospy.Rate(500) # (10) = 10[Hz]

    # Arreglo de 12 servos donde se almacenaran los datos a publicar
    angulos = Int32MultiArray()
    angulo_plot = Pose()

    # Angulos iniciales
    angulos.data = [90,90,90,87,141,57,60,120,120,60,87,87]
    angulo_plot.position.x = 0

    # ============== WHILE LOOP ===========================
    while not rospy.is_shutdown():  # Confirma que todo esta bien
        start = time.time()
        # Uso de variables globales
        global PWM, error_roll, error_pitch, error_sum, filter_rate, Kp, Ki, datos_recabados

        # Almacenamiento en arreglo del publicador
        if RPY[0] == 0 and RPY[1] == 0:
        	angulos.data = [90,90,90,87,138,60,60,120,120,60,87,87];
        else:
            angulos.data[0] = PWM[0]
            angulos.data[1] = PWM[1]
            angulos.data[2] = PWM[2]
            angulos.data[3] = PWM[3]
            angulos.data[4] = PWM[4]
            angulos.data[5] = PWM[5]
            angulos.data[6] = PWM[6]
            angulos.data[7] = PWM[7]
            angulos.data[8] = PWM[8]
            angulos.data[9] = PWM[9]
            angulos.data[10] = PWM[10]
            angulos.data[11] = PWM[11]

            angulo_plot.position.x = angulos.data[10] # el servo de posicion 10 de graficacion

        # Impresion de datos de calculo
        #print "eR: ",error_roll,"eP: ", error_pitch," eI: ",error_sum," eD: ",filter_rate, " Kp: ",Kp, " Ki: ",Ki
        #print "Roll: ", RPY[0], " Pitch: ", RPY[1]
        # Guarda un archivo de texto en la misma ruta de los datos recabados 
        np.savetxt('dp_PID.txt',datos_recabados,fmt = '%10.5f', delimiter = '\t')

        # Publicacion del mensaje
        pub.publish(angulos)	#publicador de datos
        #pub_plot.publish(angulo_plot) #publicador de graficacion

        # Delay del programa definido en el rate
        rate.sleep()
        end = time.time()
        #print(end - start)

# ================= LOOP =====================
if __name__ == '__main__':
    try:
        RPY_listener_and_PWM_talker()
    except rospy.ROSInterruptException:
        pass
