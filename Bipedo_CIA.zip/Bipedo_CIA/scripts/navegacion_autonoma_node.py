#!/usr/bin/env python

# ------------- DEPENDENCIAS Y BIBLIOTECAS  ------------------
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import time
from time import time as Time_c
import random
import math

import rospy
import serial     # esta la usas solo si recibes los datos de la IMU directamente
from std_msgs.msg import Int32MultiArray
from std_msgs.msg import Float32
from geometry_msgs.msg import Vector3Stamped
from geometry_msgs.msg import Pose

i = 0
datos_angulos = np.genfromtxt('/home/sigmadrian/Curso_ROS/catkin_ws/src/Bipedo_CIA/scripts/Tray3.txt', delimiter = '\t')

dim_trayectoria = 6008		#5888 + 120
data = np.zeros((dim_trayectoria,12)) #trayectoria
a = 120

for n in xrange(0, dim_trayectoria - a):
    data[n+a,0] = datos_angulos[n,0]
    data[n+a,1] = datos_angulos[n,1]
    data[n+a,2] = datos_angulos[n,2]
    data[n+a,3] = datos_angulos[n,3]
    data[n+a,4] = datos_angulos[n,4]
    data[n+a,5] = datos_angulos[n,5]
    data[n+a,6] = datos_angulos[n,6]
    data[n+a,7] = datos_angulos[n,7]
    data[n+a,8] = datos_angulos[n,8]
    data[n+a,9] = datos_angulos[n,9]
    data[n+a,10] = datos_angulos[n,10]
    data[n+a,11] = datos_angulos[n,11]

datos_recabados = np.zeros((dim_trayectoria,25))

eP_pitch = np.arange(-90, 90,0.1)

eP_pitch_ENG = fuzz.trimf(eP_pitch, [-90,-90,-15])#error negativo grande
eP_pitch_ENP = fuzz.trimf(eP_pitch,[-60,-15,0])#error negativo pequeno
eP_pitch_ECC = fuzz.trapmf(eP_pitch,[-15,-5,5,15])#error cercano cero
eP_pitch_EPP = fuzz.trimf(eP_pitch,[0,15,60])#error positivo pequeno
eP_pitch_EPG = fuzz.trimf(eP_pitch, [15,90,90])#error positivo grande

eI_pitch = np.arange(-200, 200,0.1)

eI_pitch_ENG = fuzz.trimf(eI_pitch, [-200,-200,-50])#error negativo grande
eI_pitch_ENP = fuzz.trimf(eI_pitch,[-100,-50,0])#error negativo pequeno
eI_pitch_ECC = fuzz.trimf(eI_pitch,[-50,0,50])#error cercano cero
eI_pitch_EPP = fuzz.trimf(eI_pitch,[0,50,100])#error positivo pequeno
eI_pitch_EPG = fuzz.trimf(eI_pitch, [50,200,200])#error positivo grande

eD_pitch = np.arange(-300, 300,0.1)

eD_pitch_ENG = fuzz.trimf(eD_pitch, [-300,-300,-50])#error negativo grande
eD_pitch_ENP = fuzz.trimf(eD_pitch,[-100,-50,0])#error negativo pequeno
eD_pitch_ECC = fuzz.trapmf(eD_pitch,[-50,-5,5,50])#error cercano cero
eD_pitch_EPP = fuzz.trimf(eD_pitch,[0,50,100])#error positivo pequeno
eD_pitch_EPG = fuzz.trimf(eD_pitch, [50,300,300])#error positivo grande

# eP_roll = np.arange(-90, 90,0.1)

# eP_roll_ENG = fuzz.trimf(eP_roll, [-90,-90,-15])#error negativo grande
# eP_roll_ENP = fuzz.trimf(eP_roll,[-60,-25,0])#error negativo pequeno
# eP_roll_ECC = fuzz.trapmf(eP_roll,[-25,-5,5,25])#error cercano cero
# eP_roll_EPP = fuzz.trimf(eP_roll,[0,25,60])#error positivo pequeno
# eP_roll_EPG = fuzz.trimf(eP_roll, [15,90,90])#error positivo grande

KP = np.arange(0,1.5,0.1)#angulo inicial robot: 115

KP_mf1 = fuzz.trapmf(KP, [0, 0,0.2,0.4])#angulo cercano cero
KP_mf2 = fuzz.trimf(KP, [0.2, 0.4, 0.6])#angulo pequeno cero
KP_mf3 = fuzz.trimf(KP,[0.4,0.6,0.8])#angulo mitad
KP_mf4 = fuzz.trimf(KP, [0.6, 0.9, 1.1])#angulo pequeno mitad
KP_mf5 = fuzz.trapmf(KP, [0.9, 1.1, 1.5,1.5])#angulo casi final


KI = np.arange(0,1.5,0.1)#angulo inicial robot: 65

KI_mf1 = fuzz.trapmf(KI, [0, 0,0.2,0.4])#angulo cercano cero
KI_mf2 = fuzz.trimf(KI, [0.2, 0.4, 0.6])#angulo pequeno cero
KI_mf3 = fuzz.trimf(KI,[0.4,0.6,0.8])#angulo mitad
KI_mf4 = fuzz.trimf(KI, [0.6, 0.9, 1.1])#angulo pequeno mitad
KI_mf5 = fuzz.trapmf(KI, [0.9, 1.1, 1.5,1.5])#angulo casi final

KD = np.arange(0,0.5,0.1)#angulo inicial robot: 140

KD_mf1 = fuzz.trimf(KD,[ 0,0,0.1])#angulo cercano cero
KD_mf2 = fuzz.trimf(KD, [0, 0.1, 0.2])#angulo pequeno cero
KD_mf3 = fuzz.trimf(KD,[0.1,0.2,0.3])#angulo mitad
KD_mf4 = fuzz.trimf(KD, [0.2, 0.3, 0.4])#angulo pequeno mitad
KD_mf5 = fuzz.trapmf(KD, [0.3, 0.4, 0.5,0.5])#angulo casi final

KP_roll = np.arange(0,1.5,0.1)#angulo inicial robot: 115

KP_roll_mf1 = fuzz.trapmf(KP_roll, [0, 0,0.1,0.2])#angulo cercano cero
KP_roll_mf2 = fuzz.trimf(KP_roll, [0.1, 0.2, 0.4])#angulo pequeno cero
KP_roll_mf3 = fuzz.trimf(KP_roll,[0.2,0.4,0.8])#angulo mitad
KP_roll_mf4 = fuzz.trimf(KP_roll, [0.6, 0.8, 1.1])#angulo pequeno mitad
KP_roll_mf5 = fuzz.trapmf(KP_roll, [0.8, 1.1, 1.5,1.5])#angulo casi final

KI_roll = np.arange(0,1.5,0.1)#angulo inicial robot: 65

KI_roll_mf1 = fuzz.trapmf(KI, [0, 0,0.2,0.4])#angulo cercano cero
KI_roll_mf2 = fuzz.trimf(KI, [0.2, 0.4, 0.6])#angulo pequeno cero
KI_roll_mf3 = fuzz.trimf(KI,[0.4,0.6,0.8])#angulo mitad
KI_roll_mf4 = fuzz.trimf(KI, [0.6, 0.9, 1.1])#angulo pequeno mitad
KI_roll_mf5 = fuzz.trapmf(KI, [0.9, 1.1, 1.5,1.5])#angulo casi final

KD_roll = np.arange(0,0.5,0.1)#angulo inicial robot: 140

KD_roll_mf1 = fuzz.trimf(KD,[ 0,0,0.05])#angulo cercano cero
KD_roll_mf2 = fuzz.trimf(KD, [0.05, 0.1, 0.2])#angulo pequeno cero
KD_roll_mf3 = fuzz.trimf(KD,[0.1,0.2,0.3])#angulo mitad
KD_roll_mf4 = fuzz.trimf(KD, [0.2, 0.3, 0.4])#angulo pequeno mitad
KD_roll_mf5 = fuzz.trapmf(KD, [0.3, 0.4, 0.5,0.5])#angulo casi final

Ang_RodillaD = np.arange(0,50,1)#angulo inicial robot: 140

Ang_RodillaD_mf1 = fuzz.trapmf(Ang_RodillaD,[0,0,5,10])#angulo cercano cero
Ang_RodillaD_mf2 = fuzz.trimf(Ang_RodillaD,[5, 10,15])#angulo pequeno cero
Ang_RodillaD_mf3 = fuzz.trimf(Ang_RodillaD,[5,15,25])#angulo mitad
Ang_RodillaD_mf4 = fuzz.trimf(Ang_RodillaD,[15,30,35])#angulo pequeno mitad
Ang_RodillaD_mf5 = fuzz.trapmf(Ang_RodillaD,[30,35,50,50])#angulo casi final

Ang_RodillaI = np.arange(0,50,1)#angulo inicial robot: 140

Ang_RodillaI_mf1 = fuzz.trapmf(Ang_RodillaI,[0,0,5,10])#angulo cercano cero
Ang_RodillaI_mf2 = fuzz.trimf(Ang_RodillaI,[5, 10,15])#angulo pequeno cero
Ang_RodillaI_mf3 = fuzz.trimf(Ang_RodillaI,[5,15,25])#angulo mitad
Ang_RodillaI_mf4 = fuzz.trimf(Ang_RodillaI,[15,30,35])#angulo pequeno mitad
Ang_RodillaI_mf5 = fuzz.trapmf(Ang_RodillaI,[30,35,50,50])#angulo casi final

def ErrorP_category(error_in):
    eP_pitch_ENG_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ENG,error_in)
    eP_pitch_ENP_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ENP,error_in)
    eP_pitch_ECC_cat = fuzz.interp_membership(eP_pitch,eP_pitch_ECC,error_in)
    eP_pitch_EPP_cat = fuzz.interp_membership(eP_pitch,eP_pitch_EPP,error_in)
    eP_pitch_EPG_cat = fuzz.interp_membership(eP_pitch,eP_pitch_EPG,error_in)
    return dict(NG = eP_pitch_ENG_cat, NP = eP_pitch_ENP_cat, CE = eP_pitch_ECC_cat, PP = eP_pitch_EPP_cat, PG = eP_pitch_EPG_cat)
    
def ErrorI_category(error_in):
    eI_pitch_ENG_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ENG,error_in)
    eI_pitch_ENP_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ENP,error_in)
    eI_pitch_ECC_cat = fuzz.interp_membership(eI_pitch,eI_pitch_ECC,error_in)
    eI_pitch_EPP_cat = fuzz.interp_membership(eI_pitch,eI_pitch_EPP,error_in)
    eI_pitch_EPG_cat = fuzz.interp_membership(eI_pitch,eI_pitch_EPG,error_in)
    return dict(NG = eI_pitch_ENG_cat, NP = eI_pitch_ENP_cat, CE = eI_pitch_ECC_cat, PP = eI_pitch_EPP_cat, PG = eI_pitch_EPG_cat)
    
def ErrorD_category(error_in):
    eD_pitch_ENG_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ENG,error_in)
    eD_pitch_ENP_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ENP,error_in)
    eD_pitch_ECC_cat = fuzz.interp_membership(eD_pitch,eD_pitch_ECC,error_in)
    eD_pitch_EPP_cat = fuzz.interp_membership(eD_pitch,eD_pitch_EPP,error_in)
    eD_pitch_EPG_cat = fuzz.interp_membership(eD_pitch,eD_pitch_EPG,error_in)
    return dict(NG = eD_pitch_ENG_cat, NP = eD_pitch_ENP_cat, CE = eD_pitch_ECC_cat, PP = eD_pitch_EPP_cat, PG = eD_pitch_EPG_cat)

# def ErrorP_roll_category(error_in):
# 	eP_roll_ENG_cat = fuzz.interp_membership(eP_roll,eP_roll_ENG,error_in)
# 	eP_roll_ENP_cat = fuzz.interp_membership(eP_roll,eP_roll_ENP,error_in)
# 	eP_roll_ECC_cat = fuzz.interp_membership(eP_roll,eP_roll_ECC,error_in)
# 	eP_roll_EPP_cat = fuzz.interp_membership(eP_roll,eP_roll_EPP,error_in)
# 	eP_roll_EPG_cat = fuzz.interp_membership(eP_roll,eP_roll_EPG,error_in)
# 	return dict(NG = eP_roll_ENG_cat, NP = eP_roll_ENP_cat, CE = eP_roll_ECC_cat, PP = eP_roll_EPP_cat, PG = eP_roll_EPG_cat)


def marcador(tray):
    marcador = 0

    if tray > 500:#control postura 
        marcador = 1
        
    if tray > 640:#inicio trayectoria
        marcador = 2
        
    if tray > 1440: #caminata 1
        marcador = 3
        
    if tray > 2240:#caminata 2
        marcador = 4
        
    if tray > 3040:#caminata 3
        marcador = 5
        
    if tray > 3180:#fin trayectoria 
        marcador = 6
    
    if tray > 3680:#control postura
        marcador = 7
        
    return marcador

def Limites(angulo):
    if angulo > 180:
        angulo = 180
    if angulo < 0:
        angulo = 0
    return angulo

# ------------------------ VARIABLES GLOBALES ------------------------
PWM = [0,0,0,0,0,0,0,0,0,0,0,0] # 12 Servomotores
RPY = [0.0,0.0,0.0]     # Arreglo donde se leen Roll, Pitch & Yaw
offset_frente = 0.0      # Offset de calibracion hacia el frente del robot
bandera_calibracion = False
bandera_giro_derecho = False
bandera_giro_izquierdo = False
bandera_linea_recta = False
yaw_objetivo = 10.0         # Angulo final al que se quiere llegar
angulo_giro = 10

ahora_t = 0
ultimo_t = 0
dt = 0
error_sum_pitch = 0
error_sum_roll = 0
contador = 0
tiempo = 0
suma_tiempo = 0
filter_rate_pitch = 0
filter_rate_roll = 0


# =================== CALLBACK de ROS ==============================
def CallBack_RPY(RPY_data):
    # Uso de variables globales
    global i,ahora_t, ultimo_t, dt, error_sum_pitch, error_sum_roll, contador, tiempo, suma_tiempo, filter_rate_pitch, filter_rate_roll

    ahora_t = Time_c() # Para comenzar a medir tiempo
    # Almacenamiento de datos de la IMU
    RPY[0] = RPY_data.vector.x*57.2958
    RPY[1] = RPY_data.vector.y*57.2958

    # Calculo de los errores
    error_roll = 0 - RPY[0]
    error_pitch = 0 - RPY[1]	
    error_rate_pitch = 0
    error_rate_roll = 0
    filter_rate_pitch = filter_rate_pitch + 0.1*(error_rate_pitch - filter_rate_pitch)
    filter_rate_roll = filter_rate_roll +0.1*(error_rate_roll - filter_rate_roll)
    ultimo_t = Time_c() # Para terminar de medir tiempo
    dt = ultimo_t - ahora_t # Diferencial de tiempo
    suma_tiempo  += dt      
    error_sum_pitch += (error_pitch*dt)
    error_sum_roll += (error_roll*dt)

    #categorias errores pitch
    eP_rule = ErrorP_category(error_pitch) 
    eI_rule = ErrorI_category(error_sum_pitch)
    eD_rule = ErrorD_category(filter_rate_pitch)
    
    #categorias error roll
    eP_roll_rule = ErrorP_category(error_roll) 
    eI_roll_rule = ErrorI_category(error_sum_roll)
    eD_roll_rule = ErrorD_category(filter_rate_roll)
    
    #ERROR PITCH
    regla1_KP = np.fmax(eP_rule['NG'],eD_rule['NG'])
    regla2_KP = np.fmax(eP_rule['NP'],eD_rule['NP'])
    regla3_KP = np.fmax(eP_rule['CE'],eD_rule['CE'])
    regla4_KP = np.fmax(eP_rule['PP'],eD_rule['PP'])
    regla5_KP = np.fmax(eP_rule['PG'],eD_rule['PG'])
    
    #ERROR SUMA PITCH
    regla1_KI = np.fmax(eP_rule['NG'],eI_rule['NG'])
    regla2_KI = np.fmax(eP_rule['NP'],eI_rule['NP'])
    regla3_KI = np.fmax(eP_rule['CE'],eI_rule['CE'])
    regla4_KI = np.fmax(eP_rule['PP'],eI_rule['PP'])
    regla5_KI = np.fmax(eP_rule['PG'],eI_rule['PG'])
    
    #CAMBIO ERROR  PITCH
    regla1_KD = np.fmax(eP_rule['NG'],eD_rule['NG'])
    regla2_KD = eP_rule['NP']
    regla3_KD = eP_rule['CE']
    regla4_KD = eP_rule['PP']
    regla5_KD = np.fmax(eP_rule['PG'],eD_rule['PG'])
    
    #ERROR ROLL
    regla1_KP_roll = np.fmax(eP_roll_rule['NG'],eD_roll_rule['NG'])
    regla2_KP_roll = np.fmax(eP_roll_rule['NP'],eD_roll_rule['NP'])
    regla3_KP_roll = np.fmax(eP_roll_rule['CE'],eD_roll_rule['CE'])
    regla4_KP_roll = np.fmax(eP_roll_rule['PP'],eD_roll_rule['PP'])
    regla5_KP_roll = np.fmax(eP_roll_rule['PG'],eD_roll_rule['PG'])
    
    #ERROR SUMA ROLL
    regla1_KI_roll = np.fmax(eP_roll_rule['NG'],eI_roll_rule['NG'])
    regla2_KI_roll = np.fmax(eP_roll_rule['NP'],eI_roll_rule['NP'])
    regla3_KI_roll = np.fmax(eP_roll_rule['CE'],eI_roll_rule['CE'])
    regla4_KI_roll = np.fmax(eP_roll_rule['PP'],eI_roll_rule['PP'])
    regla5_KI_roll = np.fmax(eP_roll_rule['PG'],eI_roll_rule['PG'])
    
    #CAMBIO ERROR  ROLL
    regla1_KD_roll = np.fmax(eP_roll_rule['NG'],eD_roll_rule['NG'])
    regla2_KD_roll = eP_roll_rule['NP']
    regla3_KD_roll = eP_roll_rule['CE']
    regla4_KD_roll = eP_roll_rule['PP']
    regla5_KD_roll = np.fmax(eP_roll_rule['PG'],eD_roll_rule['PG'])
    
    # #ERROR ROLL cadera
    # regla1_KP_roll_c = eP_roll_rule['NG']
    # regla2_KP_roll_c = eP_roll_rule['NP']
    # regla3_KP_roll_c = eP_roll_rule['CE']
    # regla4_KP_roll_c = eP_roll_rule['PP']
    # regla5_KP_roll_c = eP_roll_rule['PG']
    
    #ANGULO RODILLA 
    regla1_ang_rodillaD = eP_roll_rule['NG']
    regla2_ang_rodillaD = eP_roll_rule['NP']
    regla3_ang_rodillaD = eP_roll_rule['CE']
    regla4_ang_rodillaD = eP_roll_rule['PP']
    regla5_ang_rodillaD = eP_roll_rule['PG']
    
    #ANGULO RODILLA 
    regla1_ang_rodillaI = eP_roll_rule['NG']
    regla2_ang_rodillaI = eP_roll_rule['NP']
    regla3_ang_rodillaI = eP_roll_rule['CE']
    regla4_ang_rodillaI = eP_roll_rule['PP']
    regla5_ang_rodillaI = eP_roll_rule['PG']
    
    #Implementacion de reglas KP,KI,KD
    regla1_KP_act = np.fmin(regla1_KP,KP_mf5)#si ENG y  entonces KP mf5 nivel alto
    regla2_KP_act = np.fmin(regla2_KP,KP_mf3)#si ENP y entonces KP mf2, nivel bajo
    regla3_KP_act = np.fmin(regla3_KP,KP_mf1)#si ECC y entonces KP mf3
    regla4_KP_act = np.fmin(regla4_KP,KP_mf3)#si EPP y entonces KP mf4
    regla5_KP_act = np.fmin(regla5_KP,KP_mf5)#si EPG y entonces KP mf5
    
    regla1_KI_act = np.fmin(regla1_KI,KI_mf1)#si ENG y ENG entonces KI mf1
    regla2_KI_act = np.fmin(regla2_KI,KI_mf3)#si ENP y entonces KI mf2
    regla3_KI_act = np.fmin(regla3_KI,KI_mf4)#si ECC y entonces KI mf3
    regla4_KI_act = np.fmin(regla4_KI,KI_mf3)#si EPP y entonces KI mf4
    regla5_KI_act = np.fmin(regla5_KI,KI_mf1)#si EPG y entonces KI mf5

    regla1_KD_act = np.fmin(regla1_KD,KD_mf4)#si ENG y ENG entonces KD mf1
    regla2_KD_act = np.fmin(regla2_KD,KD_mf2)#si ENP y entonces KD mf2
    regla3_KD_act = np.fmin(regla3_KD,KD_mf1)#si ECC y entonces KD mf3
    regla4_KD_act = np.fmin(regla4_KD,KD_mf2)#si EPP y entonces KD mf4
    regla5_KD_act = np.fmin(regla5_KD,KD_mf4)#si EPG y entonces KD mf5
    
    regla1_KP_roll_act = np.fmin(regla1_KP_roll,KP_roll_mf2)#si ENG y  entonces KP mf5 nivel alto
    regla2_KP_roll_act = np.fmin(regla2_KP_roll,KP_roll_mf1)#si ENP y entonces KP mf2, nivel bajo
    regla3_KP_roll_act = np.fmin(regla3_KP_roll,KP_roll_mf1)#si ECC y entonces KP mf3
    regla4_KP_roll_act = np.fmin(regla4_KP_roll,KP_roll_mf1)#si EPP y entonces KP mf4
    regla5_KP_roll_act = np.fmin(regla5_KP_roll,KP_roll_mf2)#si EPG y entonces KP mf5

    regla1_KI_roll_act = np.fmin(regla1_KI_roll,KI_roll_mf1)#si ENG y  entonces KP mf5 nivel alto
    regla2_KI_roll_act = np.fmin(regla2_KI_roll,KI_roll_mf2)#si ENP y entonces KP mf2, nivel bajo
    regla3_KI_roll_act = np.fmin(regla3_KI_roll,KI_roll_mf3)#si ECC y entonces KP mf3
    regla4_KI_roll_act = np.fmin(regla4_KI_roll,KI_roll_mf2)#si EPP y entonces KP mf4
    regla5_KI_roll_act = np.fmin(regla5_KI_roll,KI_roll_mf1)#si EPG y entonces KP mf5

    regla1_KD_roll_act = np.fmin(regla1_KD_roll,KD_roll_mf2)#si ENG y  entonces KP mf5 nivel alto
    regla2_KD_roll_act = np.fmin(regla2_KD_roll,KD_roll_mf1)#si ENP y entonces KP mf2, nivel bajo
    regla3_KD_roll_act = np.fmin(regla3_KD_roll,KD_roll_mf1)#si ECC y entonces KP mf3
    regla4_KD_roll_act = np.fmin(regla4_KD_roll,KD_roll_mf1)#si EPP y entonces KP mf4
    regla5_KD_roll_act = np.fmin(regla5_KD_roll,KD_roll_mf2)#si EPG y entonces KP mf5
    
    regla1_ang_rodillaD_act = np.fmin(regla1_ang_rodillaD,Ang_RodillaD_mf5)#si ENG y ENG entonces KD mf1
    regla2_ang_rodillaD_act = np.fmin(regla2_ang_rodillaD,Ang_RodillaD_mf3)#si ENP y entonces KD mf2
    regla3_ang_rodillaD_act = np.fmin(regla3_ang_rodillaD,Ang_RodillaD_mf1)#si ECC y entonces KD mf3
    regla4_ang_rodillaD_act = np.fmin(regla4_ang_rodillaD,Ang_RodillaD_mf3)#si EPP y entonces KD mf4
    regla5_ang_rodillaD_act = np.fmin(regla5_ang_rodillaD,Ang_RodillaD_mf5)#si EPG y entonces KD mf5
    
    regla1_ang_rodillaI_act = np.fmin(regla1_ang_rodillaI,Ang_RodillaI_mf5)#si ENG y ENG entonces KD mf1
    regla2_ang_rodillaI_act = np.fmin(regla2_ang_rodillaI,Ang_RodillaI_mf3)#si ENP y entonces KD mf2
    regla3_ang_rodillaI_act = np.fmin(regla3_ang_rodillaI,Ang_RodillaI_mf1)#si ECC y entonces KD mf3
    regla4_ang_rodillaI_act = np.fmin(regla4_ang_rodillaI,Ang_RodillaI_mf3)#si EPP y entonces KD mf4
    regla5_ang_rodillaI_act = np.fmin(regla5_ang_rodillaI,Ang_RodillaI_mf5)#si EPG y entonces KD mf5
    
    SumaMembresiasKP = np.fmax(regla1_KP_act,np.fmax(regla2_KP_act,np.fmax(regla3_KP_act,np.fmax(regla4_KP_act,regla5_KP_act))))
    SumaMembresiasKI =  np.fmax(regla1_KI_act,np.fmax(regla2_KI_act,np.fmax(regla3_KI_act,np.fmax(regla4_KI_act,regla5_KI_act))))
    SumaMembresiasKD = np.fmax(regla1_KD_act,np.fmax(regla2_KD_act,np.fmax(regla3_KD_act,np.fmax(regla4_KD_act,regla5_KD_act))))
    
    SumaMembresiasKP_roll = np.fmax(regla1_KP_roll_act,np.fmax(regla2_KP_roll_act,np.fmax(regla3_KP_roll_act,np.fmax(regla4_KP_roll_act,regla5_KP_roll_act))))
    SumaMembresiasKI_roll = np.fmax(regla1_KI_roll_act,np.fmax(regla2_KI_roll_act,np.fmax(regla3_KI_roll_act,np.fmax(regla4_KI_roll_act,regla5_KI_roll_act))))
    SumaMembresiasKD_roll = np.fmax(regla1_KD_roll_act,np.fmax(regla2_KD_roll_act,np.fmax(regla3_KD_roll_act,np.fmax(regla4_KD_roll_act,regla5_KD_roll_act))))
    
    SumaMembresias_a_D = np.fmax(regla1_ang_rodillaD_act,np.fmax(regla2_ang_rodillaD_act,np.fmax(regla3_ang_rodillaD_act,np.fmax(regla4_ang_rodillaD_act,regla5_ang_rodillaD_act))))
    SumaMembresias_a_I = np.fmax(regla1_ang_rodillaI_act,np.fmax(regla2_ang_rodillaI_act,np.fmax(regla3_ang_rodillaI_act,np.fmax(regla4_ang_rodillaI_act,regla5_ang_rodillaI_act))))
    
    #defuzzification, resultado:
    Kp_pitch = fuzz.centroid(KP, SumaMembresiasKP)
    Ki_pitch = fuzz.centroid(KI, SumaMembresiasKI)
    Kd_pitch = fuzz.centroid(KD, SumaMembresiasKD) 
    
    Kp_roll = fuzz.centroid(KP_roll, SumaMembresiasKP_roll) 
    Ki_roll = fuzz.centroid(KI_roll, SumaMembresiasKI_roll)
    Kd_roll = fuzz.centroid(KD_roll, SumaMembresiasKD_roll)

    a_D = fuzz.centroid(Ang_RodillaD, SumaMembresias_a_D) 
    a_I = fuzz.centroid(Ang_RodillaI, SumaMembresias_a_I) 
    
    #ADQUISiCION DE DATOS, GRAFICAS
    '''datos_recabados[i,0] = suma_tiempo
    datos_recabados[i,1] = error_pitch
    datos_recabados[i,2] = error_roll
    datos_recabados[i,3] = error_rate_pitch
    datos_recabados[i,4] = error_rate_roll
    datos_recabados[i,5] = filter_rate_pitch
    datos_recabados[i,6] = filter_rate_roll
    datos_recabados[i,7] = error_sum_pitch
    datos_recabados[i,8] = error_sum_roll
    datos_recabados[i,9] = Kp_pitch
    datos_recabados[i,10] = Ki_pitch
    datos_recabados[i,11] = Kd_pitch
    datos_recabados[i,12] = Kp_roll
    datos_recabados[i,13] = Ki_roll
    datos_recabados[i,14] = Kd_roll'''

    if (i < a + 1):
        servo11 = 90
        servo12 = 90
        servo21 = Limites(int(90 + Kp_roll*error_roll + Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo22 = Limites(int(90 + Kp_roll*error_roll + Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo31 = Limites(int(150 - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch - a_D))#cadera PID
        servo32 = Limites(int(45 + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch +  a_I))#cadera PID
        servo41 = Limites(int(65 - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch - a_D))#Rodilla
        servo42 = Limites(int(120 + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch + a_I))#Rodilla
        servo51 = Limites(int(120 - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch - a_D))#Tobillo PID
        servo52 = Limites(int(65 + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch + a_I))#Tobillo PID
        servo61 = Limites(int(90 + Kp_roll*error_roll+ Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo62 = Limites(int(95 + Kp_roll*error_roll+ Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
    if(i > a ):
        servo12 = int(data[i,0]) 
        servo11 = int(data[i,1]) 
        servo22 = Limites(int(data[i,2] + Kp_roll*error_roll + Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo21 = Limites(int(data[i,3] + Kp_roll*error_roll + Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo32 = Limites(int(data[i,4] + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch ))#+  a_I))#cadera PID
        servo31 = Limites(int(data[i,5] - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch ))#- a_D))#cadera PID
        servo42 = Limites(int(data[i,6] + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch ))#+ a_I))#Rodilla
        servo41 = Limites(int(data[i,7] - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch ))#- a_D))#Rodilla
        servo52 = Limites(int(data[i,8] + Kp_pitch*error_pitch + Ki_pitch*error_sum_pitch + Kd_pitch*error_rate_pitch ))#+ a_I))#Tobillo PID
        servo51 = Limites(int(data[i,9] - Kp_pitch*error_pitch - Ki_pitch*error_sum_pitch - Kd_pitch*error_rate_pitch ))#- a_D))#Tobillo PID
        servo62 = Limites(int(data[i,10] + Kp_roll*error_roll+ Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))
        servo61 = Limites(int(data[i,11] + Kp_roll*error_roll+ Ki_roll*error_sum_roll + Kd_roll*error_rate_roll))

    PWM[0] = servo11             # servo11
    PWM[1] = servo12             # servo12
    PWM[2] = servo21             # servo21
    PWM[3] = servo22             # servo22
    PWM[4] = servo31#cadera PID  # servo31
    PWM[5] = servo32#cadera PID  # servo32
    PWM[6] = servo41#Rodilla     # servo41
    PWM[7] = servo42#Rodilla     # servo42
    PWM[8] = servo51#Tobillo PID # servo51
    PWM[9] = servo52-5#Tobillo PID # servo52
    PWM[10] = servo61-10            # servo61
    PWM[11] = servo62-5            # servo62

    i = i + 1	# Para ser utilizado por las matrices de arriba

# ================== INTERRUPCION POR /yaw Y LEY DE CONTROL DE NAVEGACION ====================
def CallBack_Yaw(Yaw_data):     # La MPU-6050 entrega angulos de 0 a 360 grados
    global bandera_calibracion, offset_frente

    if bandera_calibracion == False:
        offset_frente = 300.0 - Yaw_data.data

        bandera_calibracion = True
        #print "offset_frente = ",offset_frente
    
    else:
        RPY[2] = Yaw_data.data + offset_frente
        #print "Yaw_actual = ",RPY[2]," Yaw_objetivo= ",yaw_objetivo

# ====================== Publicador y Subscriptor =======================
def Bipedo_Publisher_and_Subscriber():
    global bandera_giro_izquierdo, bandera_giro_derecho, bandera_linea_recta

    # Nombre del nodo, false para que no despliegue numero aleatorio
    rospy.init_node('navegacion_autonoma_node', anonymous=False)
    print("Inicializando navegacion_autonoma_node...")

    # Definicion del publicador
    pub = rospy.Publisher('/servos_topic', Int32MultiArray, queue_size=10)
    #pub_plot = rospy.Publisher('/servo_plot_compu', Pose, queue_size=10)

    # Definicion del subscriptor
    rospy.Subscriber('/imu/rpy', Vector3Stamped, CallBack_RPY)
    rospy.Subscriber('/yaw', Float32, CallBack_Yaw)
    #rospy.spin() <-------- este es remplazado por while not rospy.is_shutdown()    

    # Velocidad del programa
    rate = rospy.Rate(500) # (10) = 10[Hz]

    # Arreglo de 12 servos donde se almacenaran los datos a publicar
    angulos = Int32MultiArray()
    #angulo_plot = Pose()

    # Datos iniciales
    angulos_iniciales = [90,90,90,87,141,57,60,120,120,60,87,87]
    angulos.data = angulos_iniciales
    #angulo_plot.position.x = 0

    print "El robot marchara hasta encontrar el angulo de giro programado"
    print "El angulo objetivo es: ",yaw_objetivo

    # Para indicarle al robot que girara hacia la izquierda o derecha
    if  True:#yaw_objetivo > 90 and yaw_objetivo < 270:
        bandera_giro_derecho = False
        bandera_giro_izquierdo = True
        print "El giro sera izquierdo"
    #elif yaw_objetivo < 90 or yaw_objetivo > 270:
    #    bandera_giro_derecho = True
    #    bandera_giro_izquierdo = False
    #    print "El giro sera derecho"
    #sleep(2)

    # ============== WHILE LOOP ===========================
    while not rospy.is_shutdown():  # Confirma que todo esta bien

        # Uso de variables globales
        global i,PWM, error_roll, error_pitch, error_sum, filter_rate, Kp, Ki, datos_recabados

        # Almacenamiento en arreglo del publicador <------------ CAMBIAR A FORLOOP

        # Filtro para evitar que de golpes de senal abruptos:
        if RPY[0] == 0 and RPY[1] == 0:
            angulos.data = [90,90,90,87,141,57,60,120,120,60,87,87];
        else:
            # Con giro hacia la derecha
            if bandera_giro_derecho == True and bandera_giro_izquierdo == False:
                angulos.data[0] = PWM[0]-angulo_giro					# Cambiar solo el valor del angulo de giro y su denominador
                angulos.data[1] = PWM[1]-angulo_giro-(angulos_iniciales[0]-PWM[1])*(angulo_giro/4)
            
            # Con giro hacia la izquierda
            elif bandera_giro_derecho == False and bandera_giro_izquierdo == True:
            	angulos.data[0] = PWM[0]+angulo_giro+(PWM[0]-angulos_iniciales[0])*(angulo_giro/4)
            	angulos.data[1] = PWM[1]+angulo_giro

            angulos.data[2] = PWM[2]
            angulos.data[3] = PWM[3]
            angulos.data[4] = PWM[4]
            angulos.data[5] = PWM[5]
            angulos.data[6] = PWM[6]
            angulos.data[7] = PWM[7]
            angulos.data[8] = PWM[8]
            angulos.data[9] = PWM[9]
            angulos.data[10] = PWM[10]
            angulos.data[11] = PWM[11]

            #angulo_plot.position.x = angulos.data[10] # el servo de posicion 7 de muestra

        # Impresion de datos de calculo
        #print "eR: ",error_roll,"eP: ", error_pitch," eI: ",error_sum_pitch," eD: ",filter_rate_pitch, " Kp_pitch: ",Kp_pitch, " Ki_pitch: ",Ki_pitch,"contador",i#, " Marcador: ",marcador(i) 
        #print "Roll: ", RPY[0], " Pitch: ", RPY[1]

        # Publicacion del mensaje
        pub.publish(angulos)
        #pub_plot.publish(angulo_plot)
        # Delay del programa definido en el rate
        rate.sleep()

        print "",RPY[2]
        error_Yaw = abs(yaw_objetivo-RPY[2])

        tolerancia_servos = abs(90 - angulos.data[10])

        if error_Yaw < 3:
        	bandera_llegada = True
       	else:
       		bandera_llegada = False

       	if bandera_giro_derecho == True:
       		print "Al robot le faltan ",error_Yaw," angulos a la derecha para llegar."
       	else:
       		print "Al robot le faltan ",error_Yaw," angulos a la izquierda para llegar."

       	# LLEGADA
        if bandera_llegada == True:
            print "SE HA LLEGADO AL ANGULO OBJETIVO, TRAYECTORIA TERMINADA."
            exit()

        #Sustituye el for xrange del antiguo control_completo, para que pueda salirse
        # del programa una vez completado la dimension de la trayectoria
        if i >= dim_trayectoria:
        	print "TRAYECTORIA TERMINADA"
	    	exit()

# ================= LOOP =====================
if __name__ == '__main__':
    try:
        Bipedo_Publisher_and_Subscriber()
    except rospy.ROSInterruptException:
        pass
