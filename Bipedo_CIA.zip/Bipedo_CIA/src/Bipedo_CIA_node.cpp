// Bibliotecas necesarias	
#include "ros/ros.h"
#include "sensor_msgs/Imu.h"
#include "geometry_msgs/Vector3Stamped.h"
#include "std_msgs/Float32MultiArray.h"

double YPR[3] = {0.0,0.0,0.0};	// Arreglo de datos Yaw, Pitch & Roll
int angulo = 0;					// [0,180]

// 1 radian = 57.2958

// ============================= CALLBACK ============================
void CallBack(const geometry_msgs::Vector3Stamped& ypr_msg)	// Creo el objeto ypr_msg que será el mensaje que me manda la IMU
{
	YPR[0] = ypr_msg.vector.x*57.2958;	// Obtengo y guardo el valor del x, que viene de vector, que viene de Vector3
	YPR[1] = ypr_msg.vector.y*57.2958;	// Obtengo y guardo el valor del y, que viene de vector, que viene de Vector3
	YPR[2] = ypr_msg.vector.z*57.2958;	// Obtengo y guardo el valor del z, que viene de vector, que viene de Vector3

	std::cout << YPR[0] << " " << YPR[1] << " " << YPR[2] << std::endl;
}

// =========================== INT MAIN =============================
int main(int argc, char **argv)
{
	std::cout << "Inicializando Bipedo_CIA_node" << std::endl; // Recomendado para saber desde la terminal si ya inició el nodo
	ros::init(argc, argv, "Bipedo_CIA_node");                  // "nombre del nodo" que saldra en el rosnode list

	ros::NodeHandle nh;

	// Creación del publicador que escribirá datos de servomotores
	ros::Publisher pub = nh.advertise<std_msgs::Float32MultiArray>("/servos_topic", 10);

	// Creación del subscriptor para escuchar los YPR de la IMU
	ros::Subscriber sub = nh.subscribe("/imu/rpy",10,CallBack);

	// Más grande, más rápido, mas pequeño, más lento el programa
  	ros::Rate loop_rate(100);

  	// Necesario para configurar el arreglo multidimensional flotante 32 para el publicador
	std_msgs::Float32MultiArray servos;
	servos.layout.dim.push_back(std_msgs::MultiArrayDimension());
	servos.layout.dim[0].label = "servos";
	servos.layout.dim[0].size = 1;   // De tamaño 1: prueba con 1 servo por el momento
	servos.layout.dim[0].stride = 1*1;
	servos.layout.data_offset = 0;

	// ===================== WHILE LOOP ==============================
  while (ros::ok())
  {
  	// Agrega al arreglo creado al principio los datos de servomotores
  	servos.data.push_back(YPR[0]);

  	// Publica en el objeto de datos de servomotores
  	pub.publish(servos);

  	// Limpia el publicador
  	servos.data.clear();


  	// Procesa el CallBack
		ros::spinOnce();

		// Utiliza el rate definido afuera del while
  	loop_rate.sleep();
  }
}
